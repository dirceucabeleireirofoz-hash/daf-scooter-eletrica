DAF Scooter Elétrica — projeto Android.
Inclui a logo fornecida pelo usuário como ícone, armazenamento local de orçamentos, histórico, edição e envio pelo WhatsApp.
Para compilar o APK: abrir esta pasta no Android Studio e selecionar Build > Build APK(s).
